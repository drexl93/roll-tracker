# Roll Tracker
A simple module that tracks d20 rolls and displays them in a stat card when a button is clicked.

There are options for determining what rolls are counted, as well as the maximum number of rolls to be stored per player. 
The rolls may be exported in a text file for use in other data processing software.

![Roll Tracker](https://i.imgur.com/3DsfFtO.png)
